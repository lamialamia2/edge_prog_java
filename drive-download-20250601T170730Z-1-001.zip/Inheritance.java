/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inheritance;

/**
 *
 * @author student_user
 */


 abstract class Animal{
    void sleep(){
        System.out.println(" all animal");
    }/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inheritance;

/**
 *
 * @author student_user
 */


 abstract class Animal{
    void sleep(){
        System.out.println(" all animal");
    }
     abstract void eat(); 
}
 class Dog extends Animal{
    
    void sound(){
        System.out.println("Break...Break..");
    }

    @Override
    void eat() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

class Cat extends Animal{
    void sound(){
        System.out.println("meao");
    }
    @Override
    void sleep(){
    super.sleep();
    System.out.println("I can sleep now");
}
    @Override
    void eat() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
public class Inheritance {
   public static void main(String[] args) {
       Dog d1 = new Dog();
       Cat c1 = new Cat();
  
       c1.sound();
       
       d1.sound();
       c1.sleep();
           
        
    }
}


     abstract void eat(); 
}
 class Dog extends Animal{
    
    void sound(){
        System.out.println("Break...Break..");
    }

   
    void eat() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

class Cat extends Animal{
    void sound(){
        System.out.println("meao");
    }

 
    void eat() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
public class Inheritance {
   public static void main(String[] args) {
       Dog d1 = new Dog();
       Cat c1 = new Cat();
  
       c1.sound();
       d1.sound();
       c1.sleep();
           
        
    }
}

